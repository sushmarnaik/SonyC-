﻿using System;

namespace ArticleLimited
{
    class Program
    {
        public delegate void Interest(int p,int t,int r,int n,int i);

        
        static void Main(string[] args)
        {
            Program pr = new Program();
            int[][] Customers =
            { 
                new int[] {7000,3,5,2,3},
                new int[] {5000,2,7,1,3},
                new int[] {8000,4,10,3,6},
            };
            int p, t, r, i, n;

           
            Interest intr = null;

            
            intr += new Interest(pr.simpleInterest);
            intr += new Interest(pr.compoundInterest);
            intr += new Interest(pr.realInterest);
            while(true)
            {
                Console.WriteLine("Which customer do you want to select,press 99 to exit");
                int cust = Convert.ToInt32(Console.ReadLine());
                if(cust==99)
                {
                    System.Environment.Exit(1);
                }
                cust--;
                intr(Customers[cust][0], Customers[cust][1], Customers[cust][2], Customers[cust][3], Customers[cust][4]);
            }
            

        }

        public void simpleInterest(int p,int t,int r,int n,int i)
        {
            double si = (p * t * r) / 100;
            Console.WriteLine($"Simple interest is {si}");
        }

        public void compoundInterest(int p, int t, int r,int n,int i)
        {
            double ci = (p * n * r) / 100;
            Console.WriteLine($"Compound interest is {ci}");
        }

        public void realInterest(int p,int t,int r,int n,int i)
        {
            double ri = r - i;
            Console.WriteLine($"Real interest is {ri}");
        }
    }
}
