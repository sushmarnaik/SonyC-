﻿using System;
using System.Threading;

namespace ThreadLab
{
    class Program
    {
        static void Main(string[] args)
        {
             int elapsed1, elapsed2, elapsed3;
            
            Console.WriteLine("Threading!!!");
            Thread t1 = new Thread(Threadfunc1);
            Thread t2 = new Thread(Threadfunc2);
            Thread t3 = new Thread(Threadfunc3);

            t1.Start();
            t1.Priority = ThreadPriority.Highest;
            t2.Start();
            t3.Start();
            int total;
            
        }

        public static void Threadfunc1()
        {
            
            DateTime d1 = DateTime.Now;
            Console.WriteLine($"Thread 1 started at {d1} and {d1.Millisecond} ms");
            for(int i=0;i<5;i++)
            {
                Console.WriteLine($"This is thread 1.{i}");
                Thread.Sleep(3000);
            }
            DateTime d2 = DateTime.Now;
            Console.WriteLine($"Thread 1 ended at {d2} and {d2.Millisecond} ms");
            TimeSpan elapsed = d2 - d1;
            
            Console.WriteLine($"Time taken by Thread 1 is {elapsed}");

        }

        static void Threadfunc2()
        {
            DateTime d1 = DateTime.Now;
            Console.WriteLine($"Thread 2 started at {d1} and {d1.Millisecond} ms");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"This is thread 2.{i}");
                Thread.Sleep(1000);
            }
            DateTime d2 = DateTime.Now;
            Console.WriteLine($"Thread 2 ended at {d2} and {d2.Millisecond} ms");
            TimeSpan elapsed = d2 - d1;
            Console.WriteLine($"Time taken by Thread 2 is {elapsed}");
        }

        public static void Threadfunc3()
        {
            DateTime d1 = DateTime.Now;
            
            Console.WriteLine($"Thread 3 started at {d1} and {d1.Millisecond} ms");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"This is thread 3.{i}");
                Thread.Sleep(2000);
            }
            DateTime d2 = DateTime.Now;
            Console.WriteLine($"Thread 3 ended at {d2} and {d2.Millisecond} ms");
            TimeSpan elapsed = d2 - d1;
            Console.WriteLine($"Time taken by Thread 3 is {elapsed}");
        }
    }
}

