﻿using System;
using System.Threading;

namespace Lab
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Experiment ex = new Experiment();
            ex.input();
            ex.output();
            ex.alert();
            
        }
    }
}
