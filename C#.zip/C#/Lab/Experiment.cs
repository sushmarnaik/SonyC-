﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Lab
{
    class Experiment
    {

        public delegate void above100();
        public delegate void below10();

        public event above100 a100;
        public event below10 b10;
        string exname;
        int num;
        public int temp;
        string[] chemicals = new string[5];

        public void alert()
        {
            Experiment ex = new Experiment();
            if (ex.temp < 10)
            {
                ex.a100 += new Experiment.above100(ex.above100disp);
                ex.a100();
            }
            else if (ex.temp >100)
            {
                ex.b10 += new Experiment.below10(ex.below10disp);
                ex.b10();
            }
            else
            {
                Console.WriteLine("You can continue");
            }
        }
        public void input()
        {
            Console.WriteLine("Enter experiment name");
            exname=Console.ReadLine();
            Console.WriteLine("Enter number of chemicals(<5)");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i=0; i < num;i++)
            {
                Console.WriteLine($"Enter chemical {i+1}");
                chemicals[i] = Console.ReadLine();
            }
            Console.WriteLine("Enter Temperature in C");
            temp = Convert.ToInt32(Console.ReadLine());

        }

        public void output()
        {
            Console.WriteLine($"Experiment name - {exname}");
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine($"Chemical {i + 1} is {chemicals[i]}");
            }
        }
        public void above100disp()
        {
            Console.WriteLine("Notification - Temperature has surpassed 100 C");
            Console.Beep(256, 1000);
        }

        public void below10disp()
        {
            Console.WriteLine("Notification - Temperature has come below 10 C, Failure reported");
            Console.Beep(500, 2000);
            Thread.Sleep(1000);

        }
    }
}
