﻿using System;

namespace LibraryGenerics2
{
    public interface IDefaulterList
    {
        void GetName();
        void GetYear();
        void GetBook();
        void GetBookId();
        void GetDateIssue();
        void GetDateReturn();
        void GetDefaulter();
    }
    class Program
    {
        static void Main(string[] args)
        {
            Library l = new Library();
            GenericDefaulterList<Library> gd = new GenericDefaulterList<Library>();
            //gd.getLibrary(l);
            string[] name = new string[4];
            string[] bookname = new string[4];
            int[] bookid = new int[4];
            int[] year = new int[4];
            DateTime[] dateIssued = new DateTime[4];
            DateTime[] dateReturn = new DateTime[4];
            int[] status = new int[4];

            for (int i = 0; i < 4; i++)
            {
                gd.getLibrary(l);


            }

        }
    }
}
