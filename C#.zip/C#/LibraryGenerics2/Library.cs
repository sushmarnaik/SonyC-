﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryGenerics2
{
    public class Library : IDefaulterList
    {
        public string name, bookname;
        public int year, bookid;
        public DateTime Dateissued, DateReturn;


        public void GetName()
        {
            Console.WriteLine("Enter student name");
            name = Console.ReadLine();
        }

        public void GetYear()
        {
            Console.WriteLine("Enter your year of study");
            year = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"The year of study of {name} is {year}");
        }
        public void GetBook()
        {
            Console.WriteLine("Enter the book name");
            bookname = Console.ReadLine();
        }

        public void GetBookId()
        {
            Console.WriteLine("Enter the book id");
            bookid = Convert.ToInt32(Console.ReadLine());
        }
        public void GetDateIssue()
        {
            Console.WriteLine("Enter the date issued");
            Dateissued = Convert.ToDateTime(Console.ReadLine());
        }
        public void GetDateReturn()
        {
            Console.WriteLine("Enter the date of return");
            DateReturn = Convert.ToDateTime(Console.ReadLine());
        }
        public void GetDefaulter()
        {

            if (DateTime.Now > DateReturn)
            {
                Console.WriteLine($"{name} has not returned book {bookname} with book id {bookid}");
            }
        }
    }
}
