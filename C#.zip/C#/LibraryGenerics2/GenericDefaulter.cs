﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryGenerics2
{
    public class GenericDefaulterList<T> where T : IDefaulterList
    {
        public int flag = 0;
        string n, b;
        int y, bi;
        DateTime di, dr;
        public void getLibrary(T l)
        {
            
            l.GetName();
            l.GetYear();
            l.GetBook(); 
            l.GetBookId();
            l.GetDateIssue();
                l.GetDateReturn();
            l.GetDefaulter();
        }

       

        
    }
}
