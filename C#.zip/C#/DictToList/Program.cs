﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace DictToList
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary to list");
            conversion();
        }

        static void conversion()
        {
            Dictionary<int, string> studdict = new Dictionary<int, string>(5);
            studdict.Add(1, "sushma");
            studdict.Add(2, "suma");
            studdict.Add(3, "sudha");

            var query =
                from a in studdict
                select a.Key;

            var query2 =
               from a in studdict
               select a.Value;

            List<string> studlist=studdict.Values.ToList();
            List<int> studlist2 = studdict.Keys.ToList();

            for (int i = 0; i < studlist2.Count; i++)
            {
                Console.WriteLine(studlist2[i]);
            }
            for (int i=0;i<studlist.Count;i++)
            {
                Console.WriteLine(studlist[i]);
            }

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
            foreach (var item in query2)
            {
                Console.WriteLine(item);
            }





        }
    }
}
