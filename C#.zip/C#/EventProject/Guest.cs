﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PartyProject
{
    class Guest
    {
        int choice = HomePage.select;

        string a, b;

        public void Guestlogin()
        {
            if (choice == 2)
            {
                System.Environment.Exit(1);
               

            }
        }
    }
}
