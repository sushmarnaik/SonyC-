﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewLab
{
    class Student
    {
        List<string> name = new List<string>
        { "sushma", "Rama", "Rani","Laxman" };
        List<int> id = new List<int>
         { 100, 101, 102, 103 };
        List<int> grade = new List<int>
         { 8, 3, 5, 10 };

        public void checkGrade()
        {
            IEnumerable<int> big =
            from g in grade from n in name
            where g >5
                select g;

            IEnumerable<string> big2=
                from stud in studlist
                

            foreach(var item in big)
            {
                Console.WriteLine($"High school/middle school student: {item}");
            }


        }
    }

    
}
