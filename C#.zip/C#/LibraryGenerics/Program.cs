﻿using System;

namespace LibraryGenerics
{
    struct Books
    {
        string name, bookname;
        int year, bookid;

    };
    public interface IDefaulterList
    {
        string GetName();
        int GetYear();
        string GetBook();
        int GetBookId();
        DateTime GetDateIssue();
        DateTime GetDateReturn();
        int GetDefaulter();
    }
    class Program
    {
        static void Main(string[] args)
        {
            GenericDefaulterList<Library> gd = new GenericDefaulterList<Library>();
            string[] name = new string[4];
            string[] bookname = new string[4];
            int[] bookid = new int[4];
            int[] year = new int[4];
            DateTime[] dateIssued = new DateTime[4];
            DateTime[] dateReturn = new DateTime[4];
            int[] status = new int[4];

            for (int i = 0; i < 4; i++)
            {
                gd.getLibrary();
                if (gd.getFlag() == 1)
                {
                    status[i] = 1;
                }

            }
            for (int i = 0; i < 4; i++)
            {
                if (status[i]==1)
                {
                    Console.WriteLine($"Student {name} has not returned the book {bookname} wih book ID {bookid}");
                    Console.WriteLine($"It is due by {(DateTime.Now) - dateReturn[i]} days");
                }
            }
        }
    }
}
