﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryGenerics
{
    public class GenericDefaulterList<T> where T : IDefaulterList
    {
        public int flag = 0;
        string n, b;
        int y, bi;
        DateTime di, dr;
        public void getLibrary()
        {
            Library l = new Library();
            n = l.GetName();
            y = l.GetYear();
            b = l.GetBook();
            bi = l.GetBookId();
            di = l.GetDateIssue();
            dr = l.GetDateReturn();
            if (l.GetDefaulter() == 1)
            {
                flag = 1;
            }
            else
            {
                flag = 0;
            }
        }

        public int getFlag()
        {
            return flag;
        }

        public T assign()
        {
            
            return { {n,b },{y,bi },{ di,dr} };
        }
    }
}
