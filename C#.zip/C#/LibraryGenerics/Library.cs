﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryGenerics
{
    public class Library:IDefaulterList
    {
        public string name, bookname;
        public int year,bookid;
        public DateTime Dateissued, DateReturn;

        
        public string GetName()
        {
            Console.WriteLine("Enter student name");
            name = Console.ReadLine();
            return name;
        }

        public int GetYear()
        {
            Console.WriteLine("Enter your year of study");
            year = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"The year of study of {name} is {year}");
            return year;
        }
        public string GetBook()
        {
            Console.WriteLine("Enter the book name");
            bookname = Console.ReadLine();
            return bookname;
        }

        public int GetBookId()
        {
            Console.WriteLine("Enter the book id");
            bookid = Convert.ToInt32(Console.ReadLine());
            return bookid;
        }
        public DateTime GetDateIssue()
        {
            Console.WriteLine("Enter the date issued");
            Dateissued = Convert.ToDateTime(Console.ReadLine());
            return Dateissued;
        }
        public DateTime GetDateReturn()
        {
            Console.WriteLine("Enter the date of return");
            DateReturn = Convert.ToDateTime(Console.ReadLine());
            return DateReturn;
        }
        public int GetDefaulter()
        {

            if (DateTime.Now > DateReturn)
            {
                //Console.WriteLine($"{name} has not returned book {bookname} with book id {bookid}");
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
