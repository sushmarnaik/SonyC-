﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace StudentLab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Student");
            List<Student> s = new List<Student>
            {
                new Student{name="sushma",id=1,grade=2,online=1},
                new Student{name="suma",id=2,grade=4,online=0},
                new Student{name="rama",id=3,grade=7,online=1},
                new Student{name="rama",id=4,grade=7,online=1},
                new Student{name="geetha",id=5,grade=10,online=0},
                new Student{name="Ziya",id=6,grade=4,online=1},
                new Student{name="Anusha",id=7,grade=8,online=1},

            };

            var stucheck =
                from stud in s
                where stud.grade > 5
                orderby stud.name
                select stud.name;

            foreach(var item in stucheck)
            {
                Console.WriteLine($"Middle school/High school student is : {item}");
            }

            var onlinestucheck =
                from stud in s
                where stud.online ==1
                orderby stud.name descending
                select stud.name;

            foreach (var item in onlinestucheck)
            {
                Console.WriteLine($"Online class student is : {item}");
            }
        }
    }
}
