﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentLab2
{
    class Student
    {
        public string name;
        public int id, grade;
        public int online;
    }
}
