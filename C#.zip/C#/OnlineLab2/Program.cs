﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace OnlineLab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Online class 2");
            Student s = new Student();
            

            var query =
                from n in name
                from o in online
                where o == 1
                select n;

            foreach(var item in query)
            {
                Console.WriteLine(item);
            }



        }
    }
}
