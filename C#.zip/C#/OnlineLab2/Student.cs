﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineLab2
{
    class Student
    {
        public List<string> name = new List<string>(5)
            { "sushma","rekha","jaya","nirma","ziya"};
        public int[] online = new int[5]
            { 1,0,1,0,1};
        public ArrayList online2 = new ArrayList();
        online2.Add(1);
            online2.Add(0);
            online2.Add(1);
            online2.Add(0);
            online2.Add(1);
            
    }
}
