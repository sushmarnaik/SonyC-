﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicAthlete
{
    class Activity
    {
        public string name;
        public int music;
        public int athletic;
    }
}
