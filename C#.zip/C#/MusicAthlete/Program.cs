﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace MusicAthlete
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Music/Athletics");
            List<Activity> sact = new List<Activity>
            {
                new Activity{name="sushma",music=1,athletic=1},
                new Activity{name="suma",music=0,athletic=1},
                new Activity{name="rama",music=1,athletic=0},
                new Activity{name="shama",music=1,athletic=1},

            };
            //Comprehensive
            var actcheck =
                from act in sact
                where act.athletic == 1 && act.music == 1
                select act.name;

            foreach(var item in actcheck)
            {
                Console.WriteLine($"Student in both athletics and music is {item}");
            }
            //Lambda
            var actcheck2 =
                sact.Where(n => n.athletic == 1 && n.music==1).Select(n => n.name);

            foreach (var item in actcheck2)
            {
                Console.WriteLine($"Student in both athletics and music is {item}");
            }

        }
    }
}
