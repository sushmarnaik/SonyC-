﻿using System;

namespace CustomAttribute
{
    [Own(CustomMetadata = "For interface")]
    interface MovieInterface
    {
        public void disp();
    }
    class Program
    {
        
        public string Moviename="Dhoom";
        static void Main(string[] args)
        {
            Console.WriteLine("Attributes!!!");
            
            Program p = new Program();
            display(p.Moviename);
        }

        [Own(CustomMetadata ="For method")]
        static void display(string m)
        {
            Console.WriteLine("Welcome to movies");
            Console.WriteLine($"movie name is {m}");
            Movie1 m1 = new Movie1();
            m1.disp();
        }
    }

    [Own(CustomMetadata = "For property")]
    class Movie1:MovieInterface
    {
        public void disp()
        {
            Console.WriteLine("Actor is Hritik");
        }
    }
}
