﻿using System;
using System.Reflection;

namespace ReflectionDemo
{
    class Program
    {
        private int _p1=3;
        public int p1 { get { return _p1; } set { _p1 = value; } }
        public string p2 { get; set; }
        public double p3 { get; set; }
        public static void display()
        {
            Console.WriteLine("Hello World1!");
        }

        static void Main(string[] args)
        {
            
            Type type = typeof(Program);
            Type type2 = typeof(Movie);
            Program pr = new Program();
            Movie mov = new Movie();
            Console.WriteLine("Hello World!");
            display();

            ConstructorInfo constructorInfo = type2.GetConstructor(Type.EmptyTypes);
            if(constructorInfo!=null)
            {
                Console.WriteLine("const invoking");
                object instance = constructorInfo.Invoke(null);
                MethodInfo methodInfo = type2.GetMethod("display2");
                Console.WriteLine(methodInfo.Invoke(instance, new object[] { 10 }));
            }
            

            //foreach (MemberInfo item in type.GetMembers())
            //{
            //    Console.WriteLine("Members info");
            //    Console.WriteLine(item.Name);
            //}

            //foreach (PropertyInfo item in type.GetProperties())
            //{
            //    Console.WriteLine("Properties info");
            //    Console.WriteLine(item.Name);
            //}

            //foreach (MethodInfo item in type.GetMethods())
            //{
            //    Console.WriteLine("Method info");
            //    Console.WriteLine(item.Name);
            //    Console.WriteLine(item.ReturnType);
            //}

            //foreach (MemberInfo item in type2.GetMembers())
            //{
            //    Console.WriteLine("Members info of Movie");
            //    Console.WriteLine(item.Name);
            //}
        }
    }

    class Movie
    {
        private int _p4 = 5;
        public int p4 { get { return _p4; } set { _p4 = value; } }
        public  int display2(int n)
        {
            Console.WriteLine("Hello World2!");
            return this.p4 + n;
        }
        public static void display3()
        {
            Console.WriteLine("Hello World3!");
        }
    }
}
