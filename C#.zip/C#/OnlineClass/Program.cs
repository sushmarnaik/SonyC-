﻿using System;

namespace OnlineClass
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
